from playwright.sync_api import sync_playwright

URL = "https://swifttranslator.com/"

def contains_sinhala(text: str) -> bool:
    return any(0x0D80 <= ord(ch) <= 0x0DFF for ch in text)

with sync_playwright() as p:
    browser = p.chromium.launch(headless=False)
    page = browser.new_page()
    page.goto(URL, wait_until="domcontentloaded")
    page.wait_for_timeout(2000)

    input_sel = "textarea.w-full.h-80.resize-y.rounded-lg.ring-1.ring-slate-300.p-3"
    input_loc = page.locator(input_sel).first

    # take snapshot of visible candidates before typing
    candidates = page.query_selector_all("div, pre, p, span, textarea")
    before = []
    input_handle = input_loc.element_handle()

    for el in candidates:
        try:
            if input_handle and el == input_handle:
                continue
            if not el.is_visible():
                continue
            before.append((el, (el.inner_text() or "").strip()))
        except:
            pass

    # type a sample phrase to trigger Sinhala output
    input_loc.fill("Suba dawasak!")
    page.wait_for_timeout(1200)

    best = None
    best_score = -1

    for el, old in before:
        try:
            new = (el.inner_text() or "").strip()
        except:
            continue

        if not new or new == old:
            continue
        if not contains_sinhala(new):
            continue

        score = len(new)
        try:
            box = el.bounding_box()
            if box:
                score += int(box.get("width", 0) / 10) + int(box.get("height", 0) / 10)
        except:
            pass

        if score > best_score:
            best_score = score
            best = el

    if not best:
        print("❌ Could not auto-detect output element. Use Inspect → Copy selector on the Sinhala output box.")
        input("Press Enter to close...")
        browser.close()
        raise SystemExit

    # build a unique-ish selector for the found element
    selector = page.evaluate(r"""
(el) => {
  const esc = (s) => {
    try { return CSS.escape(s); } catch (e) { return s.replace(/[^a-zA-Z0-9_\-]/g, '\\\\$&'); }
  };

  if (el.id) {
    const sel = '#' + esc(el.id);
    if (document.querySelectorAll(sel).length === 1) return sel;
  }

  const parts = [];
  let cur = el;

  while (cur && cur.nodeType === 1 && cur.tagName.toLowerCase() !== 'html') {
    let part = cur.tagName.toLowerCase();
    if (cur.classList && cur.classList.length) {
      const cls = Array.from(cur.classList).slice(0, 3).map(esc);
      if (cls.length) part += '.' + cls.join('.');
    }
    let nth = 1, sib = cur;
    while ((sib = sib.previousElementSibling)) {
      if (sib.tagName === cur.tagName) nth++;
    }
    part += `:nth-of-type(${nth})`;
    parts.unshift(part);

    const sel = parts.join(' > ');
    if (document.querySelectorAll(sel).length === 1) return sel;

    cur = cur.parentElement;
  }

  return parts.join(' > ');
}
""", best)

    print("\n✅ INPUT selector:")
    print(input_sel)
    print("\n✅ OUTPUT selector (use this):")
    print(selector)

    input("\nPress Enter to close...")
    browser.close()
