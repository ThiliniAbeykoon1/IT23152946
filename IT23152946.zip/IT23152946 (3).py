\
import argparse
import time
from typing import Optional, Tuple

import openpyxl
from playwright.sync_api import sync_playwright, Page, Locator

DEFAULT_URL = "https://swifttranslator.com/"


def pick_io_locators(page: Page,
                     input_selector: Optional[str] = None,
                     output_selector: Optional[str] = None) -> Tuple[Locator, Locator]:
    if input_selector and output_selector:
        return page.locator(input_selector).first, page.locator(output_selector).first

    # Prefer textareas: first editable as input, first non-editable as output.
    textareas = page.locator("textarea")
    ta_count = textareas.count()
    if ta_count >= 2:
        input_ta = None
        for i in range(ta_count):
            if textareas.nth(i).is_editable():
                input_ta = textareas.nth(i)
                break
        if input_ta is None:
            input_ta = textareas.nth(0)

        for j in range(ta_count):
            if not textareas.nth(j).is_editable():
                return input_ta, textareas.nth(j)

        # fallback: assume second is output
        return input_ta, textareas.nth(1)

    # contenteditable fallback
    editable_div = page.locator("[contenteditable='true']").first
    if editable_div.count() > 0:
        readonly_ta = page.locator("textarea[readonly], textarea:disabled").first
        if readonly_ta.count() > 0:
            return editable_div, readonly_ta
        aria_live = page.locator("[aria-live]").first
        if aria_live.count() > 0:
            return editable_div, aria_live

    raise RuntimeError("Couldn't auto-detect input/output fields. Use --input-selector and --output-selector.")


def wait_output_stable(output_loc: Locator, timeout_s: float = 8.0, stable_for_s: float = 0.6) -> str:
    start = time.time()
    last = None
    stable_start = None

    while True:
        try:
            current = (output_loc.inner_text() or "").strip()
        except Exception:
            current = ""

        if current != last:
            last = current
            stable_start = time.time()
        else:
            if stable_start is not None and (time.time() - stable_start) >= stable_for_s:
                return current

        if (time.time() - start) >= timeout_s:
            return last or ""


def clear_input(input_loc: Locator):
    try:
        input_loc.fill("")
        return
    except Exception:
        pass

    try:
        input_loc.click()
        input_loc.press("Control+A")
        input_loc.press("Backspace")
    except Exception:
        input_loc.evaluate("(el) => { if ('value' in el) el.value=''; el.textContent=''; }")


def run_functional(page: Page, input_loc: Locator, output_loc: Locator, text_in: str, expected: str) -> Tuple[str, str]:
    clear_input(input_loc)
    try:
        input_loc.fill(text_in)
    except Exception:
        input_loc.click()
        input_loc.type(text_in)

    actual = wait_output_stable(output_loc)
    exp = (expected or "").strip()
    status = "Pass" if actual == exp else "Fail"
    return status, actual


def run_ui_realtime_and_clear(page: Page, input_loc: Locator, output_loc: Locator, text_in: str) -> Tuple[str, str]:
    clear_input(input_loc)

    changed_midway = False
    prev = (output_loc.inner_text() or "").strip()

    input_loc.click()
    for ch in text_in:
        input_loc.type(ch, delay=120)
        now = (output_loc.inner_text() or "").strip()
        if now and now != prev:
            changed_midway = True
            prev = now

    clear_input(input_loc)
    after_clear = wait_output_stable(output_loc, timeout_s=4.0, stable_for_s=0.4)

    status = "Pass" if changed_midway and after_clear == "" else "Fail"
    note = f"changed_midway={changed_midway}; after_clear='{after_clear}'"
    return status, note


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--excel", required=True, help="Path to Appendix 2 Excel file")
    ap.add_argument("--url", default=DEFAULT_URL)
    ap.add_argument("--headful", action="store_true")
    ap.add_argument("--input-selector", default=None)
    ap.add_argument("--output-selector", default=None)
    args = ap.parse_args()

    wb = openpyxl.load_workbook(args.excel)
    ws = wb.active

    # Find column indexes by header text (row 1)
    headers = [ws.cell(1, c).value for c in range(1, ws.max_column + 1)]
    def col(name: str) -> int:
        if name not in headers:
            raise RuntimeError(f"Missing required column header: {name}")
        return headers.index(name) + 1

    c_id = col("TC ID")
    c_in = col("Input")
    c_exp = col("Expected output")
    c_act = col("Actual output")
    c_status = col("Status")

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=not args.headful)
        page = browser.new_page()
        page.goto(args.url, wait_until="domcontentloaded")
        page.wait_for_timeout(1200)

        input_loc, output_loc = pick_io_locators(page, args.input_selector, args.output_selector)

        try:
            for r in range(2, ws.max_row + 1):
                tcid = ws.cell(r, c_id).value
                if not tcid:
                    continue

                text_in = ws.cell(r, c_in).value or ""
                expected = ws.cell(r, c_exp).value or ""

                if str(tcid).startswith("Pos_UI") or str(tcid).startswith("Neg_UI"):
                    status, actual = run_ui_realtime_and_clear(page, input_loc, output_loc, str(text_in))
                else:
                    status, actual = run_functional(page, input_loc, output_loc, str(text_in), str(expected))

                ws.cell(r, c_act).value = actual
                ws.cell(r, c_status).value = status
                print(f"{tcid}: {status}")

        except KeyboardInterrupt:
            print("\nStopped by user (Ctrl+C). Saving partial results...")
        finally:
            browser.close()

    out_path = args.excel.replace(".xlsx", "_results.xlsx")
    wb.save(out_path)
    print(f"\nSaved results to: {out_path}")


if __name__ == "__main__":
    main()
