from playwright.sync_api import sync_playwright

URL = "https://swifttranslator.com/"

with sync_playwright() as p:
    browser = p.chromium.launch(headless=False)
    page = browser.new_page()
    page.goto(URL, wait_until="domcontentloaded")
    page.wait_for_timeout(2000)

    print("\n--- Inputs (textarea/input/contenteditable) ---")
    for sel in ["textarea", "input", "[contenteditable='true']"]:
        loc = page.locator(sel)
        print(sel, "count =", loc.count())
        for i in range(min(loc.count(), 10)):
            el = loc.nth(i)
            try:
                editable = el.is_editable()
            except:
                editable = "?"
            try:
                id_attr = el.get_attribute("id")
                cls_attr = el.get_attribute("class")
            except:
                id_attr, cls_attr = None, None
            print(f"  {sel}[{i}] editable={editable} id={id_attr} class={cls_attr}")

    input("Press Enter to close...")
    browser.close()
